<template>
<div >
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" >
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  
  <div class="carousel-inner">
  
    <div class="carousel-item active">
      <router-link to='/shows/action'><img src="../assets\action4.jpg" alt="Action" style="width:100%; height: 400px"></router-link>
      <div class="carousel-caption d-none d-md-block">
        <h5>Action</h5>
        <p></p>
      </div>
    </div>

    <div class="carousel-item">
     <router-link to='/shows/comedy'><img src="../assets\comedy5.png" alt="Comedy" style="width:100%; height: 400px"></router-link>
      <div class="carousel-caption d-none d-md-block">
        <h5>Comedy</h5>
        <p></p>
      </div>
    </div>
    
    <div class="carousel-item">
      <router-link to='/shows/drama'><img src="../assets\Drama1.jpg" alt="Drama" style="width:100%; height: 400px"> </router-link>
      <div class="carousel-caption d-none d-md-block">
        <h5>Drama</h5>
        <p></p>
      </div>
    </div>
   
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
 </div>
</div>

<div class="container px-4" id='card'>
<div class="row gx-5" >
<div class="col"  v-for='shw in shows' :key="shw.score" style="margin-bottom:2%">
<div v-if="shw.rating.average>8">       
<div class="card" style="width: 18rem;" v-if="shw.image!= null">
  <img :src="shw.image.medium" class="card-img-top" alt="picture">
  <div class="card-body">
    <h5 class="card-title">{{shw.name}}</h5>
    <p class="card-text">{{shw.rating}}</p>
    <a class="btn btn-primary" @click='info(shw.id)' >More Information</a>
  </div>
</div>
</div>
</div>
</div>
</div>
</template>
<script>
import Axios from 'axios'
export default {
    name:'Home',
     data(){
        return{
            search:this.$route.params.data,
            shows:[],
            loading: false,
            err: '',
        }
    },
    created (){
      this.getShows();
    },
    methods:{
        getShows(){
          console.log(this.search)   
        this.loading=true;
        Axios.get("https://api.tvmaze.com/shows").then(response => {
            this.shows = response.data;
            this.id=this.shows[0].show.id;
            this.loading=false;
        }).catch(err =>{
            this.laoding=false;
            this.err='Somthing went wrong....'
            console.log('error', err)
        });
        },
    }
}
</script>
<style  scoped>
#size{
  height: 4px;
  width: 1200px;
}
</style>